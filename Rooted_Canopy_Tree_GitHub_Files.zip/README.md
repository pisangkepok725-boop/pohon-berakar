# Rooted Canopy Trees (Minecraft Bedrock)

A prototype behavior pack that adds a large, blocky oak tree with a broad trunk, branching upper trunk, and wide canopy in forest biome generation.

## Install on Android
1. Download `Rooted_Canopy_Tree.mcaddon`.
2. Open the file from Downloads. Choose Minecraft if Android asks.
3. Wait for the import confirmation.
4. In a **new test world**, enable the Behavior Pack in Settings → Behavior Packs → My Packs.
5. Turn on any experimental toggles required by your Minecraft version for custom world-generation features, if Minecraft prompts for them.

**Important:** This is a prototype. It adds its own generated tree feature and does not replace every vanilla tree. It may need adjustment for the exact Bedrock version; test in a new world.

## GitHub upload
Upload the `.mcaddon` as a release asset, or upload the `behavior_packs/RootedCanopy_BP` folder contents to a repository. GitHub does not directly install an add-on; the `.mcaddon` is the installable package.
